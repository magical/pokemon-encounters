#!/usr/bin/ruby

=begin

Pokemon GBC Wild Pokemon Extraction

Copyright (C) 2005 Christopher Dickson Fritz


LICENSE

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

Because I'm lazy, I don't yet include a copy of the GNU General Public License
along with the program, even though I'm supposed to.  Go ahead and pick up a copy
at http://www.gnu.org/licenses/gpl.html or write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA to request one.


ABOUT

Currently this is a pretty stand-alone file to extract the wild Pokemon locations
for the GBC versions of the Pokemon games.  It comes with the necessary data for
the English versions of the Gold, Silver, and Crystal version Pokemon games.  In
the future I may move hash data (Pokemon names, location names) to their own files
in their own folders.

Currently, if you want to save an XML file of the output, you'll have to do so via
the console, such as:

  [chris@wild] ruby wild.rb > monsters.xml


NOTICE

There are no check to see if a binary data file exists.  I'm lazy like that.

=end

pokemonNames = Hash.new
pokemonNames['en'] = Hash[1=>'Bulbasaur',2=>'Ivysaur',3=>'Venusaur',4=>'Charmander',5=>'Charmeleon',6=>'Charizard',7=>'Squirtle',8=>'Wartortle',9=>'Blastoise',10=>'Caterpie',11=>'Metapod',12=>'Butterfree',13=>'Weedle',14=>'Kakuna',15=>'Beedrill',16=>'Pidgey',17=>'Pidgeotto',18=>'Pidgeot',19=>'Rattata',20=>'Raticate',21=>'Spearow',22=>'Fearow',23=>'Ekans',24=>'Arbok',25=>'Pikachu',26=>'Raichu',27=>'Sandshrew',28=>'Sandslash',29=>'Nidoran(f)',30=>'Nidorina',31=>'Nidoqueen',32=>'Nidoran(m)',33=>'Nidorino',34=>'Nidoking',35=>'Clefairy',36=>'Clefable',37=>'Vulpix',38=>'Ninetales',39=>'Jigglypuff',40=>'Wigglytuff',41=>'Zubat',42=>'Golbat',43=>'Oddish',44=>'Gloom',45=>'Vileplume',46=>'Paras',47=>'Parasect',48=>'Venonat',49=>'Venomoth',50=>'Diglett',51=>'Dugtrio',52=>'Meowth',53=>'Persian',54=>'Psyduck',55=>'Golduck',56=>'Mankey',57=>'Primeape',58=>'Growlithe',59=>'Arcanine',60=>'Poliwag',61=>'Poliwhirl',62=>'Poliwrath',63=>'Abra',64=>'Kadabra',65=>'Alakazam',66=>'Machop',67=>'Machoke',68=>'Machamp',69=>'Bellsprout',70=>'Weepinbell',71=>'Victreebel',72=>'Tentacool',73=>'Tentacruel',74=>'Geodude',75=>'Graveler',76=>'Golem',77=>'Ponyta',78=>'Rapidash',79=>'Slowpoke',80=>'Slowbro',81=>'Magnemite',82=>'Magneton',83=>'Farfetch\'d',84=>'Doduo',85=>'Dodrio',86=>'Seel',87=>'Dewgong',88=>'Grimer',89=>'Muk',90=>'Shellder',91=>'Cloyster',92=>'Gastly',93=>'Haunter',94=>'Gengar',95=>'Onix',96=>'Drowzee',97=>'Hypno',98=>'Krabby',99=>'Kingler',100=>'Voltorb',101=>'Electrode',102=>'Exeggcute',103=>'Exeggutor',104=>'Cubone',105=>'Marowak',106=>'Hitmonlee',107=>'Hitmonchan',108=>'Lickitung',109=>'Koffing',110=>'Weezing',111=>'Rhyhorn',112=>'Rhydon',113=>'Chansey',114=>'Tangela',115=>'Kangaskhan',116=>'Horsea',117=>'Seadra',118=>'Goldeen',119=>'Seaking',120=>'Staryu',121=>'Starmie',122=>'Mr.Mime',123=>'Scyther',124=>'Jynx',125=>'Electabuzz',126=>'Magmar',127=>'Pinsir',128=>'Tauros',129=>'Magikarp',130=>'Gyarados',131=>'Lapras',132=>'Ditto',133=>'Eevee',134=>'Vaporeon',135=>'Jolteon',136=>'Flareon',137=>'Porygon',138=>'Omanyte',139=>'Omastar',140=>'Kabuto',141=>'Kabutops',142=>'Aerodactyl',143=>'Snorlax',144=>'Articuno',145=>'Zapdos',146=>'Moltres',147=>'Dratini',148=>'Dragonair',149=>'Dragonite',150=>'Mewtwo',151=>'Mew',152=>'Chikorita',153=>'Bayleef',154=>'Meganium',155=>'Cyndaquil',156=>'Quilava',157=>'Typhlosion',158=>'Totodile',159=>'Croconaw',160=>'Feraligatr',161=>'Sentret',162=>'Furret',163=>'Hoothoot',164=>'Noctowl',165=>'Ledyba',166=>'Ledian',167=>'Spinarak',168=>'Ariados',169=>'Crobat',170=>'Chinchou',171=>'Lanturn',172=>'Pichu',173=>'Cleffa',174=>'Igglybuff',175=>'Togepi',176=>'Togetic',177=>'Natu',178=>'Xatu',179=>'Mareep',180=>'Flaaffy',181=>'Ampharos',182=>'Bellossom',183=>'Marill',184=>'Azumarill',185=>'Sudowoodo',186=>'Politoed',187=>'Hoppip',188=>'Skiploom',189=>'Jumpluff',190=>'Aipom',191=>'Sunkern',192=>'Sunflora',193=>'Yanma',194=>'Wooper',195=>'Quagsire',196=>'Espeon',197=>'Umbreon',198=>'Murkrow',199=>'Slowking',200=>'Misdreavus',201=>'Unown',202=>'Wobbuffet',203=>'Girafarig',204=>'Pineco',205=>'Forretress',206=>'Dunsparce',207=>'Gligar',208=>'Steelix',209=>'Snubbull',210=>'Granbull',211=>'Qwilfish',212=>'Scizor',213=>'Shuckle',214=>'Heracross',215=>'Sneasel',216=>'Teddiursa',217=>'Ursaring',218=>'Slugma',219=>'Magcargo',220=>'Swinub',221=>'Piloswine',222=>'Corsola',223=>'Remoraid',224=>'Octillery',225=>'Delibird',226=>'Mantine',227=>'Skarmory',228=>'Houndour',229=>'Houndoom',230=>'Kingdra',231=>'Phanpy',232=>'Donphan',233=>'Porygon2',234=>'Stantler',235=>'Smeargle',236=>'Tyrogue',237=>'Hitmontop',238=>'Smoochum',239=>'Elekid',240=>'Magby',241=>'Miltank',242=>'Blissey',243=>'Raikou',244=>'Entei',245=>'Suicune',246=>'Larvitar',247=>'Pupitar',248=>'Tyranitar',249=>'Lugia',250=>'Ho-oh',251=>'Celebi',277=>'Treecko',278=>'Grovyle',279=>'Sceptile',280=>'Torchic',281=>'Combusken',282=>'Blaziken',283=>'Mudkip',284=>'Marshtomp',285=>'Swampert',286=>'Poochyena',287=>'Mightyena',288=>'Zigzagoon',289=>'Linoone',290=>'Wurmple',291=>'Silcoon',292=>'Beautifly',293=>'Cascoon',294=>'Dustox',295=>'Lotad',296=>'Lombre',297=>'Ludicolo',298=>'Seedot',299=>'Nuzleaf',300=>'Shiftry',301=>'Nincada',302=>'Ninjask',303=>'Shedinja',304=>'Taillow',305=>'Swellow',306=>'Shroomish',307=>'Breloom',308=>'Spinda',309=>'Wingull',310=>'Pelipper',311=>'Surskit',312=>'Masquerain',313=>'Wailmer',314=>'Wailord',315=>'Skitty',316=>'Delcatty',317=>'Kecleon',318=>'Baltoy',319=>'Claydol',320=>'Nosepass',321=>'Torkoal',322=>'Sableye',323=>'Barboach',324=>'Whiscash',325=>'Luvdisc',326=>'Corphish',327=>'Crawdaunt',328=>'Feebas',329=>'Milotic',330=>'Carvanha',331=>'Sharpedo',332=>'Trapinch',333=>'Vibrava',334=>'Flygon',335=>'Makuhita',336=>'Hariyama',337=>'Electrike',338=>'Manectric',339=>'Numel',340=>'Camerupt',341=>'Spheal',342=>'Sealeo',343=>'Walrein',344=>'Cacnea',345=>'Cacturne',346=>'Snorunt',347=>'Glalie',348=>'Lunatone',349=>'Solrock',350=>'Azurill',351=>'Spoink',352=>'Grumpig',353=>'Plusle',354=>'Minun',355=>'Mawile',356=>'Meditite',357=>'Medicham',358=>'Swablu',359=>'Altaria',360=>'Wynaut',361=>'Duskull',362=>'Dusclops',363=>'Roselia',364=>'Slakoth',365=>'Vigoroth',366=>'Slaking',367=>'Gulpin',368=>'Swalot',369=>'Tropius',370=>'Whismur',371=>'Loudred',372=>'Exploud',373=>'Clamperl',374=>'Huntail',375=>'Gorebyss',376=>'Absol',377=>'Shuppet',378=>'Banette',379=>'Seviper',380=>'Zangoose',381=>'Relicanth',382=>'Aron',383=>'Lairon',384=>'Aggron',385=>'Castform',386=>'Volbeat',387=>'Illumise',388=>'Lileep',389=>'Cradily',390=>'Anorith',391=>'Armaldo',392=>'Ralts',393=>'Kirlia',394=>'Gardevoir',395=>'Bagon',396=>'Shelgon',397=>'Salamence',398=>'Beldum',399=>'Metang',400=>'Metagross',401=>'Regirock',402=>'Regice',403=>'Registeel',404=>'Kyogre',405=>'Groudon',406=>'Rayquaza',407=>'Latias',408=>'Latios',409=>'Jirachi',410=>'Deoxys',411=>'Chimecho']
wild_locations = Hash.new

wild_locations['gold'] = Hash[
	1=>Hash[
		12=>"Route 38",
		13=>"Route 39",
	],
	2=>Hash[
		5=>"Route 42",
		6=>"Route 44",
	],
	3=>Hash[
		2=>"Sprout Tower 2F",
		3=>"Sprout Tower 3F",
		5=>"Tin Tower 1F",
		6=>"Tin Tower 2F",
		7=>"Tin Tower 3F",
		8=>"Tin Tower 4F",
		9=>"Tin Tower 5F",
		10=>"Tin Tower 6F",
		11=>"Tin Tower 7F",
		12=>"Tin Tower 8F",
		13=>"Burned Tower 1F",
		14=>"Burned Tower B1F",
		15=>"National Park",
		22=>"Ruins of Alph (outside)",
		27=>"Ruins of Alph (inside)",
		29=>"Union Cave 1F",
		30=>"Union Cave B1F",
		31=>"Union Cave B2F",
		32=>"Slowpoke Well 1F",
		33=>"Slowpoke Well B1F",
		44=>"Ilex Forest",
		49=>"Mt. Mortar 1F",
		50=>"Mt. Mortar (center entrance cave)",
		51=>"Mt. Mortar (center inner cave)",
		52=>"Mt. Mortar B1F",
		53=>"Ice Path 1F",
		54=>"Ice Path B1F",
		55=>"Ice Path B2F (Ecruteak side)",
		56=>"Ice Path B2F (Mahogany side)",
		57=>"Ice Path B3F",
		58=>"Whirl Islands (upper-left island)",
		59=>"Whirl Islands (upper-right island)",
		60=>"Whirl Islands (lower-left island)",
		61=>"Whirl Islands B1F (center cave)",
		62=>"Whirl Islands (lower-right island)",
		63=>"Whirl Islands B1F",
		64=>"Whirl Islands B2F",
		65=>"Whirl Islands B2F (inner)",
		66=>"Silver Cave 1F (entrance)",
		67=>"Silver Cave 1~2F (inner)",
		68=>"Silver Cave 2F (inner, Red)",
		69=>"Silver Cave 2F (center room)",
		70=>"Dark Cave (Violet side)",
		71=>"Dark Cave (Blackthorn side)",
		74=>"Tohjo Falls",
		75=>"Diglett's Cave",
		76=>"Mt. Moon",
		78=>"Rock Tunnel B1F",
		79=>"Rock Tunnel B2F",
		82=>"Victory Road",
	],
	5=>Hash[
		8=>"Route 45",
		9=>"Route 46",
	],
	6=>Hash[
		7=>"Route 18",
	],
	7=>Hash[
		12=>"Route 4",
		13=>"Route 9",
		14=>"Route 10",
		15=>"Route 24",
		16=>"Route 25",
	],
	8=>Hash[
		6=>"Route 33",
	],
	9=>Hash[
		5=>"Route 43",
	],
	10=>Hash[
		1=>"Route 32",
		2=>"Route 35",
		3=>"Route 36",
		4=>"Route 37",
	],
	11=>Hash[
		1=>"Route 34",
	],
	12=>Hash[
		1=>"Route 6",
		2=>"Route 11",
	],
	13=>Hash[
		1=>"Route 1",
	],
	14=>Hash[
		1=>"Route 3",
	],
	17=>Hash[
		1=>"Route 12",
		2=>"Route 13",
		3=>"Route 14",
		4=>"Route 17",
	],
	18=>Hash[
		1=>"Route 8",
	],
	19=>Hash[
		1=>"Route 28",
		2=>"Mt. Silver Foot",
	],
	21=>Hash[
		1=>"Route 7",
		2=>"Route 15",
		3=>"Route 16",
	],
	23=>Hash[
		1=>"Route 2",
		2=>"Route 22",
	],
	24=>Hash[
		1=>"Route 26",
		2=>"Route 27",
		3=>"Route 29",
	],
	25=>Hash[
		1=>"Route 5",
	],
	26=>Hash[
		1=>"Route 30",
		2=>"Route 31",
	],
]
wild_locations['silver'] = wild_locations['gold']
# Crystal's is similar to Gold's, but with some minor changes.
wild_locations['crystal'] = wild_locations['gold']
wild_locations['crystal'][3][37] = "Union Cave 1F";
wild_locations['crystal'][3][38] = "Union Cave B1F";
wild_locations['crystal'][3][39] = "Union Cave B2F";
wild_locations['crystal'][3][40] = "Slowpoke Well B1F";
wild_locations['crystal'][3][41] = "Slowpoke Well B2F";
wild_locations['crystal'][3][52] = "Ilex Forest";
wild_locations['crystal'][3][57] = "Mt. Mortar 1F~2F";
wild_locations['crystal'][3][58] = "Mt. Mortar 1F (inner)";
wild_locations['crystal'][3][59] = "Mt. Mortar 2F (inner)";
wild_locations['crystal'][3][60] = "Mt. Mortar B1F";
wild_locations['crystal'][3][61] = "Ice Path 1F";
wild_locations['crystal'][3][62] = "Ice Path B1F";
wild_locations['crystal'][3][63] = "Ice Path B2F (Ecruteak side)";
wild_locations['crystal'][3][64] = "Ice Path B2F (Mahogany side)";
wild_locations['crystal'][3][65] = "Ice Path B3F";
wild_locations['crystal'][3][66] = "Whirl Islands (upper-left island)";
wild_locations['crystal'][3][67] = "Whirl Islands (upper-right island)";
wild_locations['crystal'][3][68] = "Whirl Islands (lower-left island)";
wild_locations['crystal'][3][69] = "Whirl Islands B1F (center cave)";
wild_locations['crystal'][3][70] = "Whirl Islands (lower-right island)";
wild_locations['crystal'][3][71] = "Whirl Islands B1F";
wild_locations['crystal'][3][72] = "Whirl Islands B2F";
wild_locations['crystal'][3][73] = "Whirl Islands B2F (inner)";
wild_locations['crystal'][3][74] = "Silver Cave 1F (entrance)";
wild_locations['crystal'][3][75] = "Silver Cave 1~2F (inner)";
wild_locations['crystal'][3][76] = "Silver Cave 2F (inner, Red)";
wild_locations['crystal'][3][77] = "Silver Cave 2F (center room)";
wild_locations['crystal'][3][78] = "Dark Cave (Violet side)";
wild_locations['crystal'][3][79] = "Dark Cave (Blackthorn side)";
wild_locations['crystal'][3][83] = "Tohjo Falls";
wild_locations['crystal'][3][84] = "Diglett's Cave";
wild_locations['crystal'][3][85] = "Mt. Moon";
wild_locations['crystal'][3][87] = "Rock Tunnel B1F";
wild_locations['crystal'][3][88] = "Rock Tunnel B2F";
wild_locations['crystal'][3][91] = "Victory Road";
wild_locations['crystal'][17][1] = "Route 13";
wild_locations['crystal'][17][2] = "Route 14";
wild_locations['crystal'][17][3] = "Route 15";
wild_locations['crystal'][21][2] = "Route 16";
wild_locations['crystal'][21][3] = "Route 17";
wild_locations['crystal'][17][4] = "Route 18";
wild_locations['crystal'][6][7] = "Route 21";

puts '<?xml version="1.0" encoding="UTF-8"?>'

versions = Array['Gold', 'Silver', 'Crystal']
languages = Array['en']
regions = Array['Johto', 'Kanto']
amounts = Hash['Johto'=>61, 'Kanto'=>30]

puts '<wild>'
for version in versions
for region in regions
for language in languages
  File.open("wildPokemon#{version}#{region}.#{language}.bin", "r") do |aFile|
    puts "<game version=\"#{version}\" region=\"#{region}\" language=\"#{language}\">"
    rates = Hash.new
    for num in (1..amount)
      loc_main = aFile.getc
      loc_sub = aFile.getc
      location = wild_locations[version.downcase][loc_main][loc_sub]
      for time in (1..3)
        rates[time] = aFile.getc;
      end
      puts "<area main=\"#{loc_main}\" sub=\"#{loc_sub}\" name=\"#{location}\">"
      for time in (1..3)
        print '<monsters time="'
        case time
          when 1
          print 'Morn'
          when 2
          print 'Day'
          when 3
          print 'Night'
        end
        puts "\" rate=\"#{rates[time]}\">"
        for monster in (1..7)
          level = aFile.getc
          number = aFile.getc
          puts "<pokemon level=\"#{level}\" number=\"#{number}\" name=\"#{pokemonNames['en'][number]}\"/>";
        end
        puts '</monsters>'
        puts
      end
      puts '</area>'
      puts
    end
    puts '</game>'
    puts
  end
end
end
end
puts '</wild>'
